# Flux Observer Sensor

[MESC Book](https://davidmolony.github.io/MESC_Firmware/operation/CONTROL.html#the-sensorless-observer)